import Vue from 'vue'
import VueSlideToggle from 'vue-slide-toggle'

Vue.use(VueSlideToggle)
