import Vue from 'vue'
import AppImage from '../components/AppImage/AppImage'

Vue.component('app-image', AppImage)
