module.exports = {
  title: 'Stays',
  description: 'Описание страницы',
  keywords: '',
  components: [
    {
      name: 'housing_page'
    }
  ]
}
