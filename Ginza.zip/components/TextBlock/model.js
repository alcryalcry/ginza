export default (info) => {
  const {
    text = ''
  } = info

  return {
    text
  }
}
