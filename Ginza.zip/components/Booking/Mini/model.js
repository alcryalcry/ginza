export default (info) => {
  const {
    title = ''
  } = info || {}

  return {
    title
  }
}
