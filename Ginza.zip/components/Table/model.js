export default (info) => {
  return info || []
}
